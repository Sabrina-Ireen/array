import array
arr = array.array('i', [0]*5)  # fixed size in heap
for i in range(5):
    arr[i] = i + 10
print(arr.tolist())
