#include <iostream>
using namespace std;
int main() {
    int size = 5;
    int arr[size]; // allocated with known size
    for (int i = 0; i < size; i++) arr[i] = i + 1;
    for (int i = 0; i < size; i++) cout << arr[i] << " ";
    return 0;
}
