#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
    int* arr = (int*)malloc(5 * sizeof(int)); // fixed heap memory
    for (int i = 0; i < 5; i++) arr[i] = i + 10;
    for (int i = 0; i < 5; i++) cout << arr[i] << " ";
    free(arr);
    return 0;
}
