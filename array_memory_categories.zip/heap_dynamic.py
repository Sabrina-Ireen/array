arr = []
arr.append(10)
arr.append(20)
arr.append(30)  # list grows automatically
print(arr)
