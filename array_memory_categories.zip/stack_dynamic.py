def stack_array():
    arr = [1, 2, 3, 4, 5]  # stack inside function
    print(arr)
stack_array()
